#pragma once
#include "JAR-Template/drive.h"

class Drive;

extern Drive chassis;

void default_constants();

void drive_test();
void Safe_AWP();
void AWP_Steal();
void Six_Ball();
void odom_test();
void tank_odom_test();
void rotation_tuner();
void return_tester();